import React from "react";

const Spinner=() =>{
return (
    <div>
        <div className="spinner"></div>
    </div>
);
}

export default Spinner;