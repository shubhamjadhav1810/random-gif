import axios from "axios";
import React, { useEffect, useState } from "react";
import Spinner from "./Spinner.js";
import useGif from "../hooks/useGif.js";

const API_KEY=process.env.Api_key;


const Tag=() =>{

    const[tag,setTag]=useState('apple');

    // const [gif , setGif]=useState('');

    // const[loader,setLoader]=useState(false);

    

    // async function fetchData(){

    //     setLoader(true);
    //     const url=`https://api.giphy.com/v1/gifs/random?api_key=XwbytOHSa34K24HaxbAs4ItBrh6VI9Fu&tag=${tag}`;
    //     //API_KEY not working in url ${API_KEY}  so direct key used  ^^^^^^^^^^^^^^^^^^^

    //     const {data} = await axios.get(url);
    //     const imgSource = data.data.images.downsized_large.url;
    //     setGif(imgSource);
    //      setLoader(false);

    // }

    // useEffect( ()=>{
    //    fetchData()
    // },[])

    // function clickHandler(){
    //  fetchData();
    // }

const{gif,loader,fetchData}=useGif(tag);

    function changeHandler(event){
      setTag(event.target.value)
    }

return (
    <div className="bg-yellow-400 w-1/2   rounded-lg flex flex-col items-center gap-y-4">
        <h1 className="text-2xl underline uppercase font-bold mt-[10px]">Random {tag} GIF</h1>
        {
            loader ?(<Spinner/>):(<img src={gif} width={450}/>)
        }

        <input
        className="w-10/12 text-md py-2 text-center"
        onChange={changeHandler}
        value={tag}
        />

        <button className="bg-slate-900 text-white w-10/12 text-lg py-2 rounded-lg mb-[10px]" onClick={()=>fetchData(tag)}>
            Generate
        </button>
    </div>
);
}

export default Tag;