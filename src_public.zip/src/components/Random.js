import axios from "axios";
import React, { useEffect, useState } from "react";
import Spinner from "./Spinner.js";
import useGif from "../hooks/useGif.js";

const API_KEY=process.env.Api_key;


const Random=() =>{

    const{gif,loader,fetchData}=useGif();

    // function clickHandler(){
    //  fetchData();
    // }

return (
    <div className="bg-green-400 w-1/2   rounded-lg flex flex-col items-center gap-y-4">
        <h1 className="text-2xl underline uppercase font-bold mt-[10px]">A Random GIF</h1>
        {
            loader ?(<Spinner/>):(<img src={gif} width={450}/>)
        }

        <button className="bg-slate-900 text-white w-10/12 text-lg py-2 rounded-lg mb-[10px]" onClick={()=>fetchData()}>
            Generate
        </button>
    </div>
);
}

export default Random;