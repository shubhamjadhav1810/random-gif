import axios from "axios";
import React, { useEffect, useState } from "react";
 

const API_KEY=process.env.Api_key;

const url1=`https://api.giphy.com/v1/gifs/random?api_key=XwbytOHSa34K24HaxbAs4ItBrh6VI9Fu`;
//API_KEY not working in url ${API_KEY}  so direct key used  ^^^^^^^^^^^^^^^^^^^


const useGif=() =>{

    const [gif , setGif]=useState('');

    const[loader,setLoader]=useState(false);

    

    async function fetchData(tag){

        setLoader(true);
        
         

        const {data} = await axios.get(tag? `${url1}&tag=${tag}`:url1);
        const imgSource = data.data.images.downsized_large.url;
        setGif(imgSource);
        setLoader(false);

    }

    useEffect( ()=>{
       fetchData('apple')
    },[])

 return {gif,loader,fetchData};
 
}

export default useGif;