import Random from "./components/Random.js";
import Tag from "./components/Tag.js";
import { FcLike } from "react-icons/fc";

export default function App() {
  return (
    <div className="flex flex-col w-full h-screen items-center background relative overflow-x-hidden">
      <h1 className="bg-white rounded-lg w-11/12 text-center mt-[30px] p-2 text-3xl font-bold">Random GIFS</h1>
      <div className="flex flex-col w-full items-center gap-y-10 mt-[30px]">
        <Random/>
        <Tag/>
      </div>
      <h2 className=" flex bg-white w-full rounded-sm justify-center gap-x-1"> Made with <FcLike className="mt-[4px]"/> by <h2 className="font-bold"> Shubham Jadhav</h2> </h2>
    </div>
  );
}
